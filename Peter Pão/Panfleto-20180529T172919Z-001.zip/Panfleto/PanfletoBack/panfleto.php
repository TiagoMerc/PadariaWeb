<!DOCTYPE html>
<html>
<html lang="pt-BR">
<meta charset="utf-8">
<title>Peter Pão
</title>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href="panfleto.css" rel="stylesheet">
    <link href="panfleto.js">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<nav id = "nb" class="navbar navbar-default">
  <div id = "container-navbar" class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
        <a class = "navbar-brand">
            <h3>Peter Pão <img src="paoIcon.png" class="logo" width="60">
            </h3>
        </a>
    </div>
   <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav navbar-right">
        <li class="active"><a href="panfleto.php">Home</a></li>
        <li><a href="historia.php">Nossa História</a></li>
        <li><a href="produto.php">Nossos Produtos</a></li>
        <li><a href="chegar.php">Como Chegar</a></li>
        <li><a href="fale.php">Fale Conosco</a></li>
      </ul>
    </div>
  </div>
</nav>

<!---<div id = "bg" class = "container-fluid"> -->

<div id="container_carousel" class="container">

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div id = "ig" class="carousel-inner" role="listbox">

        <div class="item active">
          <img src="Imagens/1.png" alt="Pao" align="middle">
        </div>

        <div class="item">
          <img  src="Imagens/2.png" alt="Bolo" align="middle">
        </div>

        <div class="item">
          <img  src="Imagens/3.png" alt="Sonho" align="middle">
        </div>

    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

  <div id="servicos" class="container-fluid">
    <h2> Nossos Serviços </h2>
                <div class="panel panel-default">
                  <div class="panel-heading">Funcionamento</div>
                  <div class="panel-body">A Peter Pão é aberta todos os dias da semana das 6h às 21h, pronta para te atender! </div>
                </div>

                <div class="panel panel-default">
                  <div class="panel-heading">Quer fazer uma encomenda?</div>
                  <div class="panel-body">A Peter Pão aceita encomendas de paẽs, bolos, doces, tortas e salgados. Consulte na nossa sessão de <a href="produto.php">produtos</a> todos os nossos sabores! Para fazer o seu pedido, ligue para nós!</div>
                </div>
  </div>

<div id="eventos" class="container-fluid">
  <h3>Próximos Eventos</h3>
   <div class="table-responsive">
      <table class="table">
        <tbody>
          <tr>
            <td>
                <figure>
                    <figcaption class="figure-caption">De 02 a 07 de Abril</figcaption>
                    <img class="img-responsive" src="Imagens/3.jpg" alt="Donuts">
                    <figcaption class="figure-caption">Festival de Donuts</figcaption>
                </figure>
            </td>
            <td>
                <figure>
                    <figcaption class="figure-caption">13 de Maio</figcaption>
                    <img class="img-responsive" src="Imagens/mae.jpg" alt="Mães">
                    <figcaption class="figure-caption">Café da Manhã Dia das Mães</figcaption>
                </figure>

            </td>
            <td>
                <figure>
                    <figcaption class="figure-caption">Julho</figcaption>
                    <img class="img-responsive" src="Imagens/integral.jpg" alt="Integral">
                    <figcaption class="figure-caption">Mês dos Pães Integrais</figcaption>
                </figure>
            <td>
          </tr>
        </tbody>
      </table>
    </div>
</div>

<!--Footer-->
<footer class="page-footer">
    <div id="container-footer" class="container-fluid text-center">
        <div class="row">
                <img class=logo src="paoIcon.png" width="60" alt="logo">
                <p><b>Unidade 1:</b> Rua J. M. Barrie, 42. Neverland.
                <br/>
                    <b>Unidade 2:</b> Rua The Little White Bird, 12. Disneyland.
                <br/>
                    <b>Unidade 3:</b> Rua The Boy Who Wouldn’t Grow, 132. Pirate Ship.
                <br/>
                    <b>Unidade 4:</b> Avenida Once Upon a Time, 1289. Dreamland.
                <br/>
                    <b>Unidade 5:</b>  Kensington Gardens, 901. Orlando.
                </p>
        </div>
    </div>
</footer>

</body>
</html>
